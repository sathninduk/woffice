<?php
/**
 * The Footer Widgets
 */
?>
	<div class="container">
		<div class="row">

			<?php dynamic_sidebar( 'widgets' ); ?>

		</div>
	</div>