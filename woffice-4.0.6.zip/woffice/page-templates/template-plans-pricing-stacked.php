<?php
/**
 * Template Name: Page: Plans and Pricing (stacked)
 *
 * @since 3.1.2
 * @package Woffice
 * @subpackage Page Template
 */

locate_template( array( 'page-templates/template-plans-pricing.php' ), true );
