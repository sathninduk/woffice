<?php
$color_light3_border = array (
    '#content-container .item-list-tabs ul li.last select',
    ' .woocommerce #content-container div.product p.price del .amount:after',
    ' input',
    'textarea',
	'select'
);