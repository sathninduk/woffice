<?php
$color_notifications_array_green = array (
    '#buddypress div#message.updated',
    '#content-container div.wpcf7-mail-sent-ok',
    '#buddypress div#message.updated:hover',
    '#bp-avatar-feedback.updated.success',
);