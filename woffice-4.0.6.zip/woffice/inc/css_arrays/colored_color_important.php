<?php
$colored_color_important = array(
    '.list-styled li:before',
    '#nav-cart-trigger.active',
	'#main-content #buddypress #item-body .bp-subnavs ul li.current a:before',
	'#main-content #buddypress .dir-navs ul li.selected a:before',
    '#content-container .blog-next-page .navigation li.active a',
    '#buddypress #woffice-bp-sidebar #item-header #item-header-content .woffice-member-social li a:hover',
);