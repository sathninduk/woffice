<?php
$color_light3_color_important = array(
    '#right-sidebar .widget .intern-padding ul li::before',
    '#dashboard .widget .intern-padding ul li::before',
    ' #content-container .masonry-layout .box ul li::before',
    ' #content-container .learndash .notcompleted:after',
    ' #content-container #learndash_profile .notcompleted:after',
    ' #content-container .learndash .topic-notcompleted span:after',
    ' .project-assigned-head i.fa',
);