<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Title', 'woffice'),
	'description'   => __('Title with borders.', 'woffice'),
	'tab'           => __('Content Elements', 'woffice'),
);