<?php if (!defined('FW')) die( 'Forbidden' ); ?>
	
						</div><!-- #END .fw-col-sm-12  --> 
					</div><!-- #END .fw-row -->
				</div><!-- #END .fw-container --> 
			</section><!-- #END .fw-main-row -->
		</div>
	<!-- FULL WIDTH CONTAINER -->
	</div>
	<div class="intern-box">
		<?php echo $atts['content']; ?>
	</div>
	<div class="intern-padding">
		<div class="fw-page-builder-content">
			<section class="fw-main-row">
				<div class="fw-container">
					<div class="fw-row">
						<div class="fw-col-sm-12">
